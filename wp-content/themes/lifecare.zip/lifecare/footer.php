            <!-- footer area start -->
            <footer class="footer-area bg-overlay">
                <div class="container">

                    <div class="row">
                        <div class="col-lg-4 col-md-6">
                            <div class="widget widget_about pr-xl-4">
                                <div class="thumb footer-logo">
                                    <img src="assets/img/logo.jpg" alt="img">
                                </div>
                                <div class="details">
                                    <p>MediiCare to bring significant changes online based learning by doing resed cased learning by cosin extensive of arch for Driving course</p>
                                    <ul class="social-media">
                                        <li>
                                            <a class="btn-base-m" href="#">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="btn-base-m" href="#">
                                                <i class="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="btn-base-m" href="#">
                                                <i class="fa fa-instagram"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a class="btn-base-m" href="#">
                                                <i class="fa fa-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6">
                            <div class="widget widget_nav_menu">
                                <h4 class="widget-title">Quick LInks</h4>
                                <ul>
                                    <li><a href="index.html">Home</a></li>
                                    <li><a href="about.html">About</a></li>
                                    <li><a href="blog.html">Blog</a></li>
                                    <li><a href="service.html">Service</a></li>
                                    <li><a href="contact.html">Contact Us</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-2 col-md-6">
                            <div class="widget widget_nav_menu">
                                <h4 class="widget-title">Services</h4>
                                <ul>
                                    <li><a href="service.html">Dental Surgery</a></li>
                                    <li><a href="service.html">Eyes Oparetion</a></li>
                                    <li><a href="service.html">Orthopendic</a></li>
                                    <li><a href="service.html">Neurology</a></li>
                                    <li><a href="service.html">General Surgery</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6">
                            <div class="widget widget_contact pl-lg-3">
                                <h4 class="widget-title">Contact Us</h4>
                                <ul class="details">
                                    <li><i class="fa fa-phone"></i> +(111)256 3527 56</li>
                                    <li><i class="fa fa-envelope"></i> info@MediiCare.com</li>
                                    <li><i class="fa fa-map-marker"></i> Pl, London NW1 The United of Rochester Kingdom</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom text-center">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 align-self-center">
                                <p>Copyright © 2021 MediiCare. All Right reserved.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!-- footer area end -->





        </div>
    </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>
</body>

</html>