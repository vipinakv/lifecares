
<?php
/*
Template Name: Home page
*/
?>
<?php get_header(); ?>

<div class="site-content-wrap">

<section class="hero">
    <div id="carouselExampleCaptions" class="carousel-fade carousel slide" data-bs-ride="carousel">


        <div class="carousel-inner">
            <div class="carousel-item active" id="ci-1">

                <div class="container">
                    <div class="carousel-caption d-md-block">
                        <h1 class="title">
                            Top notch<br />experience
                        </h1>
                        <h2 class="subtitle">
                            Medicenter is a responsive template<br /> perfect for all screen sizes
                        </h2>
                    </div>
                </div>
            </div>
            <div class="carousel-item" id="ci-2">

                <div class="container">
                    <div class="carousel-caption d-md-block">
                        <h1 class="title">
                            Show your<br /> schedule
                        </h1>
                        <h2 class="subtitle">
                            Organize and visualize your week<br /> with build-in timetable
                        </h2>
                    </div>
                </div>
            </div>
            <div class="carousel-item" id="ci-3">

                <div class="container">
                    <div class="carousel-caption d-md-block">
                        <h1 class="title">
                            Build it<br /> your way
                        </h1>
                        <h2 class="subtitle">
                            Limitless possibilities with multiple<br /> page layouts and different shortcodes
                        </h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="container" style="position: relative;">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1">1</button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2">2</button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3">3</button>
            </div>
        </div>
        <!-- <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
<span class="carousel-control-prev-icon" aria-hidden="true"></span>
<span class="visually-hidden">Previous</span>
</button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
<span class="carousel-control-next-icon" aria-hidden="true"></span>
<span class="visually-hidden">Next</span>
</button>
-->
    </div>
</section>


<section class="hero-bottom">
    <div class="container">
        <ul class="home_box_container clearfix">
            <li class="home_box light_blue animated_element animation-fadeIn duration-500">
                <h2>
                    <a href="?page=contact" title="Emergency Case">
            Emergency Case
        </a>
                </h2>
                <div class="news clearfix">
                    <p class="text">
                        If you need a doctor urgently outside of medicenter opening hours, call emergency appointment number for emergency service.
                    </p>
                    <a class="more light icon_small_arrow margin_right_white" href="?page=contact" title="Read more">Read more</a>
                </div>
            </li>
            <li class="home_box blue animated_element animation-slideRight duration-800 delay-250">
                <h2>
                    <a href="?page=timetable" title="Doctors Timetable">
            Doctors Timetable
        </a>
                </h2>
                <div class="news clearfix">
                    <p class="text">
                        Here at medicenter we have individual doctor's lists. Click read more below to see services and current timetable for our doctors.
                    </p>
                    <a class="more light icon_small_arrow margin_right_white" href="?page=timetable" title="Read more">Read more</a>
                </div>
            </li>
            <li class="home_box dark_blue animated_element animation-slideRight200 duration-800 delay-500">
                <h2>
                    Opening Hours
                </h2>
                <ul class="items_list thin dark_blue opening_hours">
                    <li class="clearfix">
                        <span>
                Monday - Friday
            </span>
                        <div class="value">
                            8.00 - 17.00
                        </div>
                    </li>
                    <li class="clearfix">
                        <span>
                Saturday
            </span>
                        <div class="value">
                            9.30 - 17.30
                        </div>
                    </li>
                    <li class="clearfix">
                        <span>
                Sunday
            </span>
                        <div class="value">
                            9.30 - 15.00
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</section>







<section class="featured-section">
    <div class="pattern-layer"></div>
    <div class="container">
        <div class="row">

            <div class="featured-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <div class="image-layer"></div>
                    <div class="icon-box">
                        <img src="assets/img/assistance.png" alt="">
                    </div>
                    <h3><a href="#">Specialised <br> Support</a></h3>
                    <p>The hospital plays a statewide role in rehabilitation services, which includes the Acquired</p>
                </div>
            </div>

            <div class="featured-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1500ms">
                    <div class="image-layer"></div>
                    <div class="icon-box">
                        <img src="assets/img/medical-records.png" alt="">
                    </div>
                    <h3><a href="#">Diagnosis & <br> Investigation</a></h3>
                    <p>Hospital doctors examine patients so that they can diagnose and treat health conditions</p>
                </div>
            </div>

            <div class="featured-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box wow fadeInLeft" data-wow-delay="600ms" data-wow-duration="1500ms">
                    <div class="image-layer"></div>
                    <div class="icon-box">
                        <img src="assets/img/first-aid-kit.png" alt="">
                    </div>
                    <h3><a href="#">Medical & <br> Surgical</a></h3>
                    <p>Medicine is a very wide field with many possible specialisms. Some doctors work in general</p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- team area start -->
<section class="team-area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 mb-3">
                <div class="section-title text-center">
                    <h6 class="sub-title left-line">Professional Team</h6>
                    <h2 class="title">Our Professional Doctor Working For Your Health</h2>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-3 col-md-6">
                <div class="single-team-inner style-two text-center">
                    <div class="thumb">
                        <img src="https://s7template.com/tf/mediicare/assets/img/team/1.png" alt="team">
                    </div>
                    <div class="details">
                        <h4><a href="team-details.html">Madison Ava</a></h4>
                        <span>Founder</span>
                        <ul class="social-media mt-3">
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single-team-inner style-two text-center">
                    <div class="thumb">
                        <img src="https://s7template.com/tf/mediicare/assets/img/team/2.png" alt="team">
                    </div>
                    <div class="details">
                        <h4><a href="team-details.html">Madison Ava</a></h4>
                        <span>specialist</span>
                        <ul class="social-media mt-3">
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single-team-inner style-two text-center">
                    <div class="thumb">
                        <img src="https://s7template.com/tf/mediicare/assets/img/team/3.png" alt="team">
                    </div>
                    <div class="details">
                        <h4><a href="team-details.html">Madison Ava</a></h4>
                        <span>Dentalist</span>
                        <ul class="social-media mt-3">
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="single-team-inner style-two text-center">
                    <div class="thumb">
                        <img src="https://s7template.com/tf/mediicare/assets/img/team/4.png" alt="team">
                    </div>
                    <div class="details">
                        <h4><a href="team-details.html">Richard Kyle</a></h4>
                        <span>Doctor</span>
                        <ul class="social-media mt-3">
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-facebook"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-twitter"></i>
                                </a>
                            </li>
                            <li>
                                <a class="btn-base-m" href="#">
                                    <i class="fa fa-linkedin"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- team area end -->


<section class="gallery-section">
    <div class="image-layer" style="background-image:url(https://html.xpeedstudio.com/medizco/images/background/4.jpg)"></div>
    <div class="container">
        <div class="title-box">
            <h2>Gallery of Medizco Center</h2>
        </div>
        <div class="row">

            <div class="project-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image">


                        <a class="plus" href="https://html.xpeedstudio.com/medizco/images/gallery/1.jpg" data-fancybox="gallery-1" data-caption=""> <img src="https://html.xpeedstudio.com/medizco/images/gallery/1.jpg" alt=""></a>

                    </div>
                </div>
            </div>

            <div class="project-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image">


                        <a class="plus" href="https://html.xpeedstudio.com/medizco/images/gallery/2.jpg" data-fancybox="gallery-1" data-caption=""><img src="https://html.xpeedstudio.com/medizco/images/gallery/2.jpg" alt=""></span>
                        </a>

                    </div>
                </div>
            </div>

            <div class="project-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image">


                        <a class="plus" href="https://html.xpeedstudio.com/medizco/images/gallery/3.jpg" data-fancybox="gallery-1" data-caption=""><img src="https://html.xpeedstudio.com/medizco/images/gallery/3.jpg" alt=""></a>

                    </div>
                </div>
            </div>

            <div class="project-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image">


                        <a class="plus" href="https://html.xpeedstudio.com/medizco/images/gallery/4.jpg" data-fancybox="gallery-1" data-caption=""><img src="https://html.xpeedstudio.com/medizco/images/gallery/4.jpg" alt=""></a>

                    </div>
                </div>
            </div>

            <div class="project-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image">


                        <a class="plus" href="https://html.xpeedstudio.com/medizco/images/gallery/5.jpg" data-fancybox="gallery-1" data-caption=""><img src="https://html.xpeedstudio.com/medizco/images/gallery/5.jpg" alt=""></a>

                    </div>
                </div>
            </div>

            <div class="project-block col-lg-4 col-md-6 col-sm-12">
                <div class="inner-box">
                    <div class="image">


                        <a class="plus" href="https://html.xpeedstudio.com/medizco/images/gallery/6.jpg" data-fancybox="gallery-1" data-caption=""><img src="https://html.xpeedstudio.com/medizco/images/gallery/6.jpg" alt=""></a>

                    </div>
                </div>
            </div>
        </div>

        <div class="button-box text-center">
            <a href="gallery.html" class="btn-more">View All <span class="arrow icon-chevron-right"></span></a>
        </div>
    </div>
</section>


<section class="events-section">
    <div class="pattern-layer-two" style="background-image:url(https://html.xpeedstudio.com/medizco/images/background/pattern-5.png)"></div>
    <div class="container">

        <div class="title-box">
            <div class="clearfix">
                <div class="pull-left">
                    <h2>Recent Events</h2>
                </div>
                <div class="pull-right">
                    <a href="#" class="view-events">View all Events <span class="arrow fa fa-angle-right"></span></a>
                </div>
            </div>
        </div>

        <div class="inner-container">
            <div class="pattern-layer-one" style="background-image:url(https://html.xpeedstudio.com/medizco/images/background/pattern-4.png)"></div>
            <div class="row">

                <div class="column col-lg-6 col-md-12 col-sm-12">

                    <div class="event-block">
                        <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="upper-box clearfix">

                                <div class="event-date">
                                    <strong>25</strong>Dec
                                </div>
                                <div class="image">
                                    <img src="https://html.xpeedstudio.com/medizco/images/resource/author-1.jpg" alt="" />
                                </div>
                                <ul class="event-list">
                                    <li><span class="fa fa-map-marker"></span>Destiny Hall, 5th Floor</li>
                                    <li><span class="fa fa-clock-o"></span>10am to 3pm</li>
                                </ul>
                            </div>
                            <h3><a href="appointment.html">National Assessment and Accrediation for Council Peer Team Visited...</a></h3>
                            <a href="event-detail.html" class="btn-outline">join now</a>
                        </div>
                    </div>
                </div>

                <div class="column col-lg-6 col-md-12 col-sm-12">

                    <div class="event-block-two">
                        <div class="inner-box wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
                            <div class="content clearfix">

                                <div class="event-date">
                                    <strong>26</strong>Dec
                                </div>
                                <ul class="event-list">
                                    <li><span class="fa fa-map-marker"></span>Charlotte Hall</li>
                                    <li><span class="fa fa-clock-o"></span>10am to 3pm</li>
                                </ul>
                                <h3><a href="appointment.html">Medicine is a very wide field with many possible specialisms...</a></h3>
                            </div>
                        </div>
                    </div>

                    <div class="event-block-two">
                        <div class="inner-box wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="content clearfix">

                                <div class="event-date">
                                    <strong>28</strong>Dec
                                </div>
                                <ul class="event-list">
                                    <li><span class="fa fa-map-marker"></span>Royal Lounge</li>
                                    <li><span class="fa fa-clock-o"></span>10am to 3pm</li>
                                </ul>
                                <h3><a href="appointment.html">Hospital doctors examine patients so that they can diagnose...</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>